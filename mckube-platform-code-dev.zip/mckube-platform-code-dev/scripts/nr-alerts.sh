#!/bin/bash
export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export TERRAFORM_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/terraform-provider-newrelicinfra:v0.1.1"
if $(docker run --rm -v $(pwd):/workdir/config ${DOCKER_IMAGE} -config-path ./config -template "{{ .Kubernetes.Addons }}" | grep -q "new-relic")
then
	set +x
  # Vault auth
  export VAULT_ADDR=https://vault-int.mckinsey-solutions.com
  if [ "${BRANCH}" == "prod" ]; then
    export VAULT_BACKEND=mckube-prod
    vault auth -method=aws role=mckube-prod-rw-jenkins-mke
  else
    export VAULT_BACKEND=mckube-npn
    vault auth -method=aws role=mckube-npn-rw-jenkins-mke
  fi
  # Assume role
  source ./aws_creds_env.sh
  export NEWRELIC_API_KEY=$(vault read -field=key ${VAULT_BACKEND}/new-relic/api-key)
  docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file templates/nr_alerts.tf.tmpl > nr_alerts.tf
  docker pull ${TERRAFORM_IMAGE}
  DOCKER_RUN="docker run -e NEWRELIC_API_KEY=${NEWRELIC_API_KEY} -e AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID} -e AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY} -e AWS_SESSION_TOKEN=${AWS_SESSION_TOKEN} -v $(pwd):/workdir --rm"
  ${DOCKER_RUN} ${TERRAFORM_IMAGE} init
  ${DOCKER_RUN} ${TERRAFORM_IMAGE} plan -out=/workdir/nrplanfile
  ${DOCKER_RUN} ${TERRAFORM_IMAGE} apply -auto-approve /workdir/nrplanfile
else
  echo "new-relic not found in Addons";
fi
