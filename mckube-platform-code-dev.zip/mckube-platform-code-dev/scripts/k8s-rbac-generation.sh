#!/bin/bash

export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export KOPS_DOCKER_REPO="quay-int.mckinsey-solutions.com/nvt-platform/kops"
export KOPS_VERSION=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .KopsVersion }}")
export KOPS_IMAGE="${KOPS_DOCKER_REPO}:${KOPS_VERSION}"
export KUBECTL="docker run --entrypoint /usr/local/bin/kubectl -v ${PWD}:/mnt --rm ${KOPS_IMAGE} --kubeconfig=/mnt/kubeconfig"
PREFIX=$( echo $NAMESPACE_NAME | cut -c1-6)
SUFIX=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .Stage }}")
USER_NAMESPACE=$PREFIX-$SUFIX

for NAMESPACE in $NAMESPACE_NAME $USER_NAMESPACE;
do
    ROLE=$(cat << EOF
    kind: Role
    apiVersion: rbac.authorization.k8s.io/v1beta1
    metadata:
      namespace: ${NAMESPACE}
      name: user-access
    rules:
    - apiGroups: [""]
      resources: ["*"]
      verbs: ["*"]
EOF
    )

    ROLEBINDING=$(cat << EOF
    kind: RoleBinding
    apiVersion: rbac.authorization.k8s.io/v1beta1
    metadata:
      name: ${USERNAME}-${SUFIX}-binding
      namespace: ${NAMESPACE}
    subjects:
    - kind: User
      name: ${USERNAME}-${SUFIX}
      apiGroup: rbac.authorization.k8s.io
    roleRef:
      kind: Role
      name: user-access
      apiGroup: rbac.authorization.k8s.io
EOF
    )
    echo "$ROLE" > role.yaml
    echo "$ROLEBINDING" > rolebinding.yaml
    ${KUBECTL} apply -f role.yaml
    ${KUBECTL} apply -f rolebinding.yaml
done
