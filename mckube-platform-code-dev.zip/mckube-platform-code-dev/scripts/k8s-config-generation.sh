#!/bin/bash -ex

# Vault auth
export VAULT_ADDR=https://vault-int.mckinsey-solutions.com
if [ "${BRANCH}" == "prod" ]; then
  export VAULT_BACKEND=mckube-prod
  vault auth -method=aws role=mckube-prod-rw-jenkins-mke
else
  export VAULT_BACKEND=mckube-npn
  vault auth -method=aws role=mckube-npn-rw-jenkins-mke
fi

# Assume role
source ./aws_creds_env.sh

export BUCKET_NAME="$CLUSTER_NAME-kops"
export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"

# Set default region to bucket location so CLI can use correct auth
LOCATION=$(aws s3api get-bucket-location --bucket $BUCKET_NAME --query LocationConstraint --output text)
# LOCATION == null when bucket is in us-east-1, so no region needs to be set.
if [ "$LOCATION" != "None" ]; then
  export AWS_DEFAULT_REGION=$LOCATION
fi

if ! aws s3 ls "s3://$BUCKET_NAME/$CLUSTER_NAME/"; then
  echo "-!- Cluster doesn't exist yet"
  touch kubeconfig
  exit 0
fi

aws s3 sync "s3://$BUCKET_NAME/$CLUSTER_NAME/pki/issued/ca" .
aws s3 sync "s3://$BUCKET_NAME/$CLUSTER_NAME/pki/private/ca" .
mv *.crt ca.crt
mv *.key ca.key

SUFIX=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .Stage }}")
FULL_USERNAME="$USERNAME-$SUFIX"
SUBJ="/CN=$FULL_USERNAME"
for G in $K8S_GROUPS
do
	SUBJ+="/O=$G"
done
echo $SUBJ
mkdir -p $FULL_USERNAME
openssl genrsa -out "$FULL_USERNAME/$FULL_USERNAME.key" 2048
openssl req -new -key "$FULL_USERNAME/$FULL_USERNAME.key" -subj "$SUBJ" -out "$FULL_USERNAME/$FULL_USERNAME.csr"
openssl x509 -req -in "$FULL_USERNAME/$FULL_USERNAME.csr" -CA ca.crt -CAkey ca.key -CAcreateserial -out "$FULL_USERNAME/$FULL_USERNAME.crt" -days $VALIDITY
openssl x509 -req -in "$FULL_USERNAME/$FULL_USERNAME.csr" -CA ca.crt -CAkey ca.key -CAcreateserial -out "$FULL_USERNAME/$FULL_USERNAME-VAULT.crt" -days 183
openssl pkcs12 -export -out "$FULL_USERNAME/$FULL_USERNAME.pfx" -inkey "$FULL_USERNAME/$FULL_USERNAME.key" -in "$FULL_USERNAME/$FULL_USERNAME.crt" -certfile ca.crt -password pass:$USERNAME
cp ca.crt "$FULL_USERNAME/ca.crt"
CA=$(cat ca.crt | base64 | tr -d '\n')
USER_CRT=$(cat $FULL_USERNAME/$FULL_USERNAME.crt | base64 | tr -d '\n')
VAULT_CRT=$(cat $FULL_USERNAME/$FULL_USERNAME-VAULT.crt | base64 | tr -d '\n')
USER_KEY=$(cat $FULL_USERNAME/$FULL_USERNAME.key | base64 | tr -d '\n')
CONF=$(cat << EOF
apiVersion: v1
clusters:
- cluster:
    certificate-authority-data: ${CA}
    server: https://api.${CLUSTER_NAME}
  name: ${CLUSTER_NAME}
contexts:
- context:
    cluster: ${CLUSTER_NAME}
    user: ${FULL_USERNAME}
  name: ${CLUSTER_NAME}
current-context: ${CLUSTER_NAME}
kind: Config
preferences: {}
users:
- name: ${FULL_USERNAME}
  user:
    client-certificate-data: ${USER_CRT}
    client-key-data: ${USER_KEY}
EOF
)

#For Vault
VAULT=$(cat << EOF
apiVersion: v1
clusters:
- cluster:
    certificate-authority-data: ${CA}
    server: https://api.${CLUSTER_NAME}
  name: ${CLUSTER_NAME}
contexts:
- context:
    cluster: ${CLUSTER_NAME}
    user: ${FULL_USERNAME}
  name: ${CLUSTER_NAME}
current-context: ${CLUSTER_NAME}
kind: Config
preferences: {}
users:
- name: ${FULL_USERNAME}
  user:
    client-certificate-data: ${VAULT_CRT}
    client-key-data: ${USER_KEY}
EOF
)

echo "$VAULT" > $FULL_USERNAME/kubeconfig-vault.yaml
echo "$CONF" > $FULL_USERNAME/$FULL_USERNAME.yaml
cp $FULL_USERNAME/$FULL_USERNAME.yaml kubeconfig

# Writing config to Vault
vault write ${VAULT_BACKEND}/${CLUSTER_NAME}/kubeconfig value=@${FULL_USERNAME}/kubeconfig-vault.yaml

rm "$FULL_USERNAME/$FULL_USERNAME.csr" ca.*
zip "$FULL_USERNAME.zip" $FULL_USERNAME/*
mv "$FULL_USERNAME.zip" "$FULL_USERNAME"
