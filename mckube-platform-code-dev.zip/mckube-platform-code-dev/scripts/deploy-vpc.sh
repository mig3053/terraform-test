#!/bin/bash

export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export TERRAFORM_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/terraform-provider-newrelicinfra:v0.1.1"

docker pull ${DOCKER_IMAGE}
docker pull ${TERRAFORM_IMAGE}

docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path config/ -template-file templates/main.tf.tmpl > main.tf

cat main.tf

source ./aws_creds_env.sh
TF_RUN="docker run --rm -e AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID} -e AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY} -e AWS_SESSION_TOKEN=${AWS_SESSION_TOKEN} -v $(pwd):/workdir -v $HOME/.ssh:/root/.ssh:ro ${TERRAFORM_IMAGE}"

${TF_RUN} init
${TF_RUN} get
${TF_RUN} validate
${TF_RUN} plan -out=/workdir/nrplanfile
${TF_RUN} apply -auto-approve /workdir/nrplanfile
