#!/bin/bash

export VAULT_ADDR=https://vault-int.mckinsey-solutions.com
if [ "${BRANCH}" == "prod" ]; then
  export VAULT_BACKEND=mckube-prod
  vault auth -method=aws role=mckube-prod-rw-jenkins-mke
else
  export VAULT_BACKEND=mckube-npn
  vault auth -method=aws role=mckube-npn-rw-jenkins-mke
fi

GITHUB_TOKEN=$(vault read -field=token mckube-npn/jenkins/github)
API_URL="git.mckinsey-solutions.com"
PROJECT="nvt-platform/nvt-helm-releases"
BASE_BRANCH=default

if [ -z ${CLUSTER_NAME} ]; then
  echo "new branch name missing!"
  exit 1
fi

NEW_BRANCH=${CLUSTER_NAME}

SHA=$(curl -H "Content-Type: application/json" -H "Authorization: token $GITHUB_TOKEN" \
https://$API_URL/api/v3/repos/$PROJECT/git/refs/heads/$BASE_BRANCH | jq -r ".object.sha")

POST_BODY="{\"ref\":\"refs/heads/$NEW_BRANCH\",\"sha\":\"$SHA\"}"

curl -X POST -d $POST_BODY -H "Content-Type: application/json" -H "Authorization: token $GITHUB_TOKEN" \
https://$API_URL/api/v3/repos/$PROJECT/git/refs
