#!/usr/bin/env bash

set -ex

# Assume role
source ./aws_creds_env.sh

export DIR_PREFIX="/workspace"

# AWS CLI repo
export AWS_DOCKER_REPO="quay-int.mckinsey-solutions.com/nvt-platform/aws"

# Prep AWS creds for use with docker run
cp aws_creds_env.sh aws_creds_env_docker
sed -i.bak 's/export //g' aws_creds_env_docker

AWS_IMAGE="${AWS_DOCKER_REPO}:latest"
docker pull ${AWS_IMAGE}
AWS="docker run --rm -u $(id -u) -v $PWD:/workspace -w /workspace -e AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION} --env-file ./aws_creds_env_docker ${AWS_IMAGE} aws"

if [ "$SNAPSHOTS" == "" ]; then
  echo "Must specify list of snapshots to restore!"
  exit 1
fi

echo "Region is $AWS_DEFAULT_REGION"

FIRST=$(echo $SNAPSHOTS | head -n1)
FIRST_ATTR=$(${AWS} ec2 describe-snapshots --snapshot-ids $FIRST)
CLUSTER_FQDN=$(echo $FIRST_ATTR | jq -r '.Snapshots[0].Tags[] | select(.Key == "KubernetesCluster") | .Value')

echo "Pulling Terraform state..."
${AWS} s3 cp s3://${CLUSTER_FQDN}-tfstate/kops-${CLUSTER_FQDN}.tfstate ${DIR_PREFIX}/cluster.tfstate

echo "Scaling masters to 0..."
MASTER_IDS=$(${AWS} autoscaling describe-auto-scaling-groups --auto-scaling-group-names master-${AWS_DEFAULT_REGION}a.masters.${CLUSTER_FQDN} master-${AWS_DEFAULT_REGION}b.masters.${CLUSTER_FQDN} master-${AWS_DEFAULT_REGION}c.masters.${CLUSTER_FQDN} --query "AutoScalingGroups[].Instances[].InstanceId" --output text | tr '\t' ' ')

${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name master-${AWS_DEFAULT_REGION}a.masters.${CLUSTER_FQDN} --min-size 0 --max-size 0 --desired-capacity 0
${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name master-${AWS_DEFAULT_REGION}b.masters.${CLUSTER_FQDN} --min-size 0 --max-size 0 --desired-capacity 0
${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name master-${AWS_DEFAULT_REGION}c.masters.${CLUSTER_FQDN} --min-size 0 --max-size 0 --desired-capacity 0

if [ "$MASTER_IDS" != "" ]; then
  echo "Waiting for the master instances to terminate..."
  ${AWS} ec2 wait instance-terminated --instance-ids $MASTER_IDS
fi

NEW_VOLUMES=""

for s in $SNAPSHOTS; do
  ATTR=$(${AWS} ec2 describe-snapshots --snapshot-ids $s)

  AZ=$(echo $ATTR | jq -r '.Snapshots[0].Tags[] | select(.Key == "k8s.io/etcd/events") | .Value[0:1]')
  if [ "$AZ" == "" ]; then
    AZ=$(echo $ATTR | jq -r '.Snapshots[0].Tags[] | select(.Key == "k8s.io/etcd/main") | .Value[0:1]')
  fi
  FULL_AZ="${AWS_DEFAULT_REGION}${AZ}"

  echo "Creating volume from snapshot $s in AZ $FULL_AZ"
  VOL_ID=$(${AWS} ec2 create-volume --availability-zone ${FULL_AZ} --volume-type gp2 --snapshot-id $s --query 'VolumeId')
  VOL_ID=${VOL_ID//\"/}
  echo "Tagging volume $VOL_ID"
  ${AWS} ec2 describe-tags --filters "Name=resource-id,Values=${s}" --output json | jq '[.Tags[] | {"Key": .Key, "Value": .Value}] | {"DryRun": false, "Resources": ["'${VOL_ID}'"], "Tags": .}' > $PWD/tags.json
  ${AWS} ec2 create-tags --cli-input-json file://${DIR_PREFIX}/tags.json

  VOL_NAME=$(jq -r '.Tags[] | select(.Key == "Name") | .Value' $PWD/tags.json)
  TF_NAME=${VOL_NAME//./-}
  OLD_ID=$(jq -r '.modules[0].resources."aws_ebs_volume.'${TF_NAME}'".primary.id' $PWD/cluster.tfstate)
  echo "Replacing volume $OLD_ID with volume $VOL_ID in tfstate..."
  sed -i.bak "s^${OLD_ID}^${VOL_ID}^g" $PWD/cluster.tfstate

  echo "Deleting old volume $OLD_ID..."
  ${AWS} ec2 delete-volume --volume-id $OLD_ID

  NEW_VOLUMES="$NEW_VOLUMES $VOL_ID"
  OLD_VOLUMES="$OLD_VOLUMES $OLD_ID"
done

echo "Waiting for new volumes to become available..."
${AWS} ec2 wait volume-available --volume-ids $NEW_VOLUMES

echo "Waiting for old volumes to be deleted..."
${AWS} ec2 wait volume-deleted --volume-ids $OLD_VOLUMES

echo "Uploading new tfstate..."
${AWS} s3 cp s3://${CLUSTER_FQDN}-tfstate/kops-${CLUSTER_FQDN}.tfstate s3://${CLUSTER_FQDN}-tfstate/BEFORE_RESTORE-kops-${CLUSTER_FQDN}.tfstate
${AWS} s3 cp ${DIR_PREFIX}/cluster.tfstate s3://${CLUSTER_FQDN}-tfstate/kops-${CLUSTER_FQDN}.tfstate

echo "Scaling masters back to 1..."
${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name master-${AWS_DEFAULT_REGION}a.masters.${CLUSTER_FQDN} --min-size 1 --max-size 1 --desired-capacity 1
${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name master-${AWS_DEFAULT_REGION}b.masters.${CLUSTER_FQDN} --min-size 1 --max-size 1 --desired-capacity 1
${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name master-${AWS_DEFAULT_REGION}c.masters.${CLUSTER_FQDN} --min-size 1 --max-size 1 --desired-capacity 1

echo "Cleaning up..."
rm $PWD/tags.json
rm $PWD/cluster.tfstate
