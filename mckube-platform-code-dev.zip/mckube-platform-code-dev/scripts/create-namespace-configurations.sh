#!/bin/bash

set -ex

# Export the variables from the golang template
export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"

#McKube Config Applier part
docker pull ${DOCKER_IMAGE}

docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/namespaces.yaml.tmpl > namespaces.yaml
cat namespaces.yaml

docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/apply-namespace-configurations.sh.tmpl > ./scripts/apply-namespace-configurations.sh
cat ./scripts/apply-namespace-configurations.sh
