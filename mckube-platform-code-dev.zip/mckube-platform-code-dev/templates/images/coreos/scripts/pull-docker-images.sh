echo "Cluster Version is $CLUSTER_VERSION"

sudo docker pull gcr.io/google_containers/kube-apiserver:v${CLUSTER_VERSION}
sudo docker pull gcr.io/google_containers/kube-scheduler:v${CLUSTER_VERSION}
sudo docker pull gcr.io/google_containers/kube-controller-manager:v${CLUSTER_VERSION}
sudo docker pull gcr.io/google_containers/kube-proxy:v${CLUSTER_VERSION}

sudo docker pull quay.io/calico/cni:v3.3.1
sudo docker pull quay.io/calico/node:v3.3.1
sudo docker pull k8s.gcr.io/etcd:3.1.17
sudo docker pull k8s.gcr.io/pause-amd64:3.0
sudo docker pull jtblin/kube2iam:0.10.4
sudo docker pull newrelic/infrastructure-k8s:1.0.0-beta2.2
