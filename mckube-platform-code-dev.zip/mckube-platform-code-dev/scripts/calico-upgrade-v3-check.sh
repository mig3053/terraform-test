#!/bin/bash

if [ "$KUBECTL" == "" ]; then
    export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
    export KOPS_DOCKER_REPO="quay-int.mckinsey-solutions.com/nvt-platform/kops"
    export KOPS_VERSION=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .KopsVersion }}")
    export KOPS_IMAGE="${KOPS_DOCKER_REPO}:${KOPS_VERSION}"
    export KUBECTL_BIN="docker run --entrypoint /usr/local/bin/kubectl -v ${PWD}:/mnt --rm ${KOPS_IMAGE} --kubeconfig=/mnt/kubeconfig --namespace kube-system"

    KUBECTL=${KUBECTL:-$KUBECTL_BIN}
fi

cat <<EOF > pod.yaml
apiVersion: v1
kind: Pod
metadata:
  name: calicoctl
  namespace: kube-system
spec:
  nodeSelector:
    beta.kubernetes.io/os: linux
  hostNetwork: true
  containers:
  - name: calicoctl
    image: quay.io/calico/ctl:v3.1.4
    command: ["/bin/sh", "-c", "while true; do sleep 3600; done"]
    env:
    - name: ETCD_ENDPOINTS
      valueFrom:
        configMapKeyRef:
          name: calico-config
          key: etcd_endpoints
    - name: APIV1_ETCD_ENDPOINTS
      valueFrom:
        configMapKeyRef:
          name: calico-config
          key: etcd_endpoints
EOF

$KUBECTL create -f /mnt/pod.yaml
$KUBECTL wait --for=condition=Ready pod/calicoctl
$KUBECTL exec calicoctl -- wget -O /calico-upgrade https://github.com/projectcalico/calico-upgrade/releases/download/v1.0.5/calico-upgrade
$KUBECTL exec calicoctl -- chmod +x /calico-upgrade

if $KUBECTL exec calicoctl -- /calico-upgrade dry-run; then
  echo "Calico is ready to upgrade to v3!"
  $KUBECTL delete -f /mnt/pod.yaml
  exit 0
else
  echo "It looks like something is wrong with the Calico setup. Review the output above, fix the issues and try again."
  $KUBECTL delete -f /mnt/pod.yaml
  exit 1
fi
