#!/bin/bash

# kubectl path
HELM="/var/lib/jenkins/libs/helm-2.6.1"
export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export KOPS_DOCKER_REPO="quay-int.mckinsey-solutions.com/nvt-platform/kops"
export KOPS_VERSION=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .KopsVersion }}")
export KOPS_IMAGE="${KOPS_DOCKER_REPO}:${KOPS_VERSION}"
export KUBECTL="docker run --entrypoint /usr/local/bin/kubectl -v ${PWD}:/mnt --rm ${KOPS_IMAGE} --kubeconfig=/mnt/kubeconfig"
export KUBECONFIG=$(pwd)/kubeconfig


# Make sure that default storage class is removed before we deploy the on-boarding addon

if $KUBECTL get storageclasses gp2; then
  $KUBECTL delete storageclass gp2
fi

# Cretaing helm service accounts
$KUBECTL --namespace=kube-system apply -f /mnt/manifests/helm-service-accounts.yaml


# Initialising the tiler on the cluster
${HELM} init --upgrade --service-account helm

#Wait for Tiller pod to be available
timeout --foreground 15m bash -c "while ! $HELM version; do sleep 2; done;"

${HELM} repo add mckube-charts https://git.mckinsey-solutions.com/pages/nvt-platform/mckube-helm-charts/

${HELM} version

cat mckube-configuration.yaml

#McKube Config Applier
docker pull ${DOCKER_IMAGE}
docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/helm-run.sh.tmpl > helm-run.sh

cat ./helm-run.sh

chmod +x ./helm-run.sh

bash -ex ./helm-run.sh
