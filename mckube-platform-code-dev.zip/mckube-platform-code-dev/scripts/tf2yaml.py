#!/usr/bin/python
from subprocess import check_output
import yaml
import sys
def main():
	public_subnet_ids = check_output(["terraform", "output", "-module=vpc", "public_subnets"])
	public_subnet_cidrs = check_output(["terraform", "output", "-module=vpc", "public_subnet_cidrs"])
	private_subnet_ids = check_output(["terraform", "output", "-module=vpc", "private_subnets"])
	private_subnet_cidrs = check_output(["terraform", "output", "-module=vpc", "private_subnet_cidrs"])
	shared_subnet_ids = check_output(["terraform", "output", "-module=vpc", "shared_subnets"])
	shared_subnet_cidrs = check_output(["terraform", "output", "-module=vpc", "shared_subnet_cidrs"])
	dnszoneid = check_output(["terraform", "output", "-module=vpc", "dns_zone_id"])
	vpc_id = check_output(["terraform", "output", "-module=vpc", "vpc_id"])
	service_access_security_group_id = check_output(["terraform", "output", "-module=vpc", "service_access_security_group_id"])

	vpcdata = dict(
		dnszone = dnszoneid.split("\n")[0],
		kopsvpc = dict (
				vpcid =  vpc_id.split("\n")[0],
				serviceaccesssecuritygroupid = service_access_security_group_id.split("\n")[0],
				privateaid = private_subnet_ids.split(",\n")[0],
				privatebid =  private_subnet_ids.split(",\n")[1],
				privatecid = private_subnet_ids.split("\n")[2],
				privateacidr = private_subnet_cidrs.split(",\n")[0],
				privatebcidr = private_subnet_cidrs.split(",\n")[1],
				privateccidr = private_subnet_cidrs.split("\n")[2],
				publicaid = public_subnet_ids.split(",\n")[0],
				publicbid = public_subnet_ids.split(",\n")[1],
				publiccid = public_subnet_ids.split("\n")[2],
				publicacidr = public_subnet_cidrs.split(",\n")[0],
				publicbcidr = public_subnet_cidrs.split(",\n")[1],
				publicccidr = public_subnet_cidrs.split("\n")[2],
				sharedaid = shared_subnet_ids.split(",\n")[0],
				sharedbid = shared_subnet_ids.split(",\n")[1],
				sharedcid = shared_subnet_ids.split("\n")[2],
				sharedacidr = shared_subnet_cidrs.split(",\n")[0],
				sharedbcidr = shared_subnet_cidrs.split(",\n")[1],
				sharedccidr = shared_subnet_cidrs.split("\n")[2]
		)
	)
	sys.stdout.write(yaml.dump(vpcdata, default_flow_style=False))

if __name__ == '__main__':
  main()
