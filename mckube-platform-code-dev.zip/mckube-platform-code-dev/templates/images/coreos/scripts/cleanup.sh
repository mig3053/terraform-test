# remove the machine id. it will be regenerated on first boot.
sudo rm -fr /etc/machine-id