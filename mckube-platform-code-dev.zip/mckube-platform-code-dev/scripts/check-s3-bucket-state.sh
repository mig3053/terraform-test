#!/bin/bash

echo "Checking if AWS cli is available on the system:"
which aws
if [ "$?" != "0" ]; then
	echo "AWS cli is not available on the system...Exiting!"
	exit 1
fi
echo "Checking if Terraform is available on the system:"
which terraform
if [ "$?" != "0" ]; then
	echo "Terraform is not installed on the system...Exiting!"
	exit 1
fi

#Printing the Bucketname

export BUCKET_NAME="$CLUSTER_NAME-tfstate"
export CLUSTER_BACKUP_BUCKET_NAME="$CLUSTER_NAME-backup"
export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export TERRAFORM_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/terraform-provider-newrelicinfra:v0.1.1"

bucket=`aws s3 ls | grep ${BUCKET_NAME} | wc -l`
if [ $bucket -lt "1" ]; then
	echo "State bucket doesn't exist! Now we're creating the bucket...."
     	docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config/mckube-configuration.yaml -template-file ./templates/s3-tf-state.tf.tmpl > s3-tf-state.tf
     	cat s3-tf-state.tf
        TF_RUN="docker run --rm -e AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID} -e AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY} -e AWS_SESSION_TOKEN=${AWS_SESSION_TOKEN} -v $(pwd):/workdir -v $HOME/.ssh:/root/.ssh:ro ${TERRAFORM_IMAGE}"
        ${TF_RUN} init && \
        ${TF_RUN} plan -out=/workdir/s3planfile && \
        ${TF_RUN} apply -auto-approve /workdir/s3planfile
fi

backup_bucket=`aws s3 ls | grep ${CLUSTER_BACKUP_BUCKET_NAME} | wc -l`
if [ $backup_bucket -lt "1" ]; then
	echo "Backup bucket doesn't exist! Now we're creating the bucket...."
	docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config/mckube-configuration.yaml -template-file ./templates/s3-cluster-backup.tf.tmpl > s3-cluster-backup.tf
	cat s3-cluster-backup.tf
	TF_RUN="docker run --rm -e AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID} -e AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY} -e AWS_SESSION_TOKEN=${AWS_SESSION_TOKEN} -v $(pwd):/workdir -v $HOME/.ssh:/root/.ssh:ro ${TERRAFORM_IMAGE}"
	${TF_RUN} init && \
	${TF_RUN} plan -out=/workdir/s3planfile && \
	${TF_RUN} apply -auto-approve /workdir/s3planfile
fi

bucket_created=`aws s3 ls | grep ${BUCKET_NAME} | wc -l`
backup_bucket_created=`aws s3 ls | grep ${CLUSTER_BACKUP_BUCKET_NAME} | wc -l`
if [ $bucket_created -lt "1" ] || [ $backup_bucket_created -lt "1" ]; then
	echo "Something went wrong exiting..."
	exit 1
else
	echo "Bucket already exists...Skipping this step!"
	exit 0
fi
