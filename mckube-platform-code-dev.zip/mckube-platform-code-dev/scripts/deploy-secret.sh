#!/bin/bash

# Vault auth
export VAULT_ADDR=https://vault-int.mckinsey-solutions.com
if [ "${BRANCH}" == "prod" ]; then
  export VAULT_BACKEND=mckube-prod
  vault auth -method=aws role=mckube-prod-rw-jenkins-mke
else
  export VAULT_BACKEND=mckube-npn
  vault auth -method=aws role=mckube-npn-rw-jenkins-mke
fi

export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export KOPS_DOCKER_REPO="quay-int.mckinsey-solutions.com/nvt-platform/kops"
export KOPS_VERSION=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .KopsVersion }}")
export KOPS_IMAGE="${KOPS_DOCKER_REPO}:${KOPS_VERSION}"
export KUBECTL="docker run --entrypoint /usr/local/bin/kubectl -v ${PWD}:/mnt --rm -w /mnt ${KOPS_IMAGE} --kubeconfig=/mnt/kubeconfig"

VAULT_OUTPUT=$(vault read -field=dockerconfigjson ${VAULT_BACKEND}/quay-secret)

cat <<EOF > quay-secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: quayauth
data:
  .dockerconfigjson: ${VAULT_OUTPUT}
type: kubernetes.io/dockerconfigjson
EOF

KUBE_CMD="${KUBECTL} --namespace=kube-system"
${KUBE_CMD} get secret quayauth || ${KUBE_CMD} create -f /mnt/quay-secret.yaml

if ! ${KUBE_CMD} get secret wildcard-kube-system-cert -n kube-system ; then
  vault read -field=crt ${VAULT_BACKEND}/${CLUSTER_NAME}/ca > ca.crt
  vault read -field=key ${VAULT_BACKEND}/${CLUSTER_NAME}/ca > ca.key

  openssl genrsa -out wildcard.key 2048
  openssl req -subj "/C=US/ST=New York/O=McKinsey&Company/CN=*.kube-system.svc" -new -key wildcard.key -out wildcard.csr
  openssl x509 -req -in wildcard.csr -CA ca.crt -CAkey ca.key -set_serial 01 -out wildcard.crt -days 3650 -sha1

  cat wildcard.crt ca.crt > combined.crt

  ${KUBE_CMD} create secret tls wildcard-kube-system-cert --cert combined.crt --key wildcard.key
fi