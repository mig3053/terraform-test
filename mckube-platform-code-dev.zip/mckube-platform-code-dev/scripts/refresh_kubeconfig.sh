#!/usr/bin/env bash

set -e
VAULT_ADDR=https://vault-int.mckinsey-solutions.com
VAULT_VERSION="0.11.6"
VAULT_CMD="docker run --rm -v $(pwd):/work -e BRANCH=${BRANCH} -e SOLUTION=${SOLUTION} -e VAULT_ADDR=${VAULT_ADDR} quay-int.mckinsey-solutions.com/platform_infra/docker-vault:${VAULT_VERSION}"

cat >update-kubeconfig.sh <<EOL
KUBECONFIG="\$(cat kubeconfig)"

# Vault auth
if [ "\${BRANCH}" == "prod" ]; then
  vault login -method=aws role=mckube-prod-rw-jenkins-mke
else
  vault login -method=aws role=mckube-npn-rw-jenkins-mke
fi

function write_kubeconfig() {
    local target_key="\$1";
    kubeconfig="\${KUBECONFIG}"; # set kubeconfig to the value of variable with name in KUBECONFIG

    if [ -z "\$kubeconfig" -o -z "\$target_key" ]; then
        echo "Kubeconfig (\$kubeconfig) and target_key (\$target_key) are required."
        exit 1;
    fi;
    set +e;
    vault read \$target_key >/dev/null 2>&1;
    if [ "\$?" -eq 0 ]; then
        echo "Writing kubeconfig to \$target_key";
        echo -n "\$kubeconfig" | vault write \$target_key value=-
    else
        echo "Skipping this one. No kubeconfig at \$target_key.";
    fi;
    set -e;
}

if [ -z \${SOLUTION} ] #If Solution Backend is specified then only that backend config needs updating
then
  SECRET_BACKENDS=\$(vault mounts -format=json | jq -r 'keys[]')
  for backend in \${SECRET_BACKENDS}
  do
    write_kubeconfig "\${backend}\${BRANCH}/kubeconfig";
  done
  echo "Kubeconfig updated for \${SECRET_BACKENDS}"
else
  write_kubeconfig "\${SOLUTION}\${BRANCH}/kubeconfig";
  echo "Kubeconfig updated for \${SOLUTION}"
fi

EOL

${VAULT_CMD} update-kubeconfig.sh