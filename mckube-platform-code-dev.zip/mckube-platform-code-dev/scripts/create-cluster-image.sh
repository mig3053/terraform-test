set -ex

export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export AWS_TIMEOUT_SECONDS=600
export AWS_POLL_DELAY_SECONDS=5
export PACKER_LOG=1

/var/lib/jenkins/libs/packer-1.1.1 build templates/images/coreos/coreos-ami.json
