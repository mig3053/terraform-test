#!/bin/bash

set -ex

export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export KOPS_DOCKER_REPO="quay-int.mckinsey-solutions.com/nvt-platform/kops"
export KOPS_VERSION=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .KopsVersion }}")
export KOPS_IMAGE="${KOPS_DOCKER_REPO}:${KOPS_VERSION}"
export KUBECTL="docker run --entrypoint /usr/local/bin/kubectl -v ${PWD}:/mnt --rm ${KOPS_IMAGE} --kubeconfig=/mnt/kubeconfig"

cat $(pwd)/kubeconfig

$KUBECTL config get-clusters
# Create namespace
if ! $KUBECTL get ns $NAMESPACE_NAME; then
    $KUBECTL create namespace $NAMESPACE_NAME --save-config
fi

# Enable network isolation
if [ "$DISABLE_NETWORK_ISOLATION" == "false" ]; then
    $KUBECTL annotate --overwrite namespace $NAMESPACE_NAME "net.beta.kubernetes.io/network-policy={\"ingress\":{\"isolation\":\"DefaultDeny\"}}"
else
    $KUBECTL annotate namespace $NAMESPACE_NAME "net.beta.kubernetes.io/network-policy-"
fi

# Apply limits and quotas
if [ "$LIMIT_PROFILE" != "None" ]; then
    $KUBECTL apply --namespace $NAMESPACE_NAME -f limits/$LIMIT_PROFILE.yaml
fi
