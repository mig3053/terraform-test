#!/bin/bash
#Retrieve bucket location for the bucket
#-r removes the quotes from the answer
BUCKET_LOCATION="$(aws s3api get-bucket-location --bucket ${BUCKET_NAME} | jq -r '.LocationConstraint')"

if [ "${BUCKET_LOCATION}" == "null" ]; then
  AWS_DEFAULT_REGION="us-east-1"
else
  AWS_DEFAULT_REGION="${BUCKET_LOCATION}"
fi

export AWS_DEFAULT_REGION
#set s3 signature to v4
aws configure set s3.signature_version s3v4

# Copy the state file locally
aws s3 cp s3://${BUCKET_NAME}/${TF_STATE_FILE} .

cat <<EOF > main.tf
provider "aws" {
  version = "~> 2.0"
  region = "${AWS_DEFAULT_REGION}"
}
EOF

export TERRAFORM_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/terraform-provider-newrelicinfra:v0.1.1"
TF_RUN="docker run --rm -w=/workdir -e AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION} -e AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID} -e AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY} -e AWS_SESSION_TOKEN=${AWS_SESSION_TOKEN} -v $(pwd):/workdir -v $HOME/.ssh:/root/.ssh:ro ${TERRAFORM_IMAGE}"

${TF_RUN} init && \
${TF_RUN} destroy -state=/workdir/${TF_STATE_FILE} --force -var "region=${AWS_DEFAULT_REGION}"
