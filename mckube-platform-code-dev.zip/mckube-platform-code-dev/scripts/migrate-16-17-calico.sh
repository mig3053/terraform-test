#!/bin/bash

# kubectl path
KUBECTL="docker run --entrypoint /usr/local/bin/kubectl -v ${PWD}:/mnt --rm ${KOPS_DOCKER_REPO} --kubeconfig=/mnt/kubeconfig"

export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export KUBECONFIG=./kubeconfig

docker pull ${DOCKER_IMAGE}
docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/migrate-16-17-calico.yaml.tmpl > migrate-16-17-calico.yaml

$KUBECTL --kubeconfig ${KUBECONFIG} --namespace=kube-system apply -f $(pwd)/migrate-16-17-calico.yaml

timeout --foreground 5m bash -c 'while [ "$(kubectl get job -n kube-system -o custom-columns=successful:.status.succeeded --no-headers -l migration-to=1.7 | grep -v 0 | wc -l)" != "2" ]; do echo "Jobs still running..."; sleep 2; done'
