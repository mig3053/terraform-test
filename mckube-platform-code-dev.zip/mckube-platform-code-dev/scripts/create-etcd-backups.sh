#!/usr/bin/env bash

set -ex

# Prep AWS creds for use with docker run
export AWS_DOCKER_REPO="quay-int.mckinsey-solutions.com/nvt-platform/aws"
cp aws_creds_env.sh aws_creds_env_docker
sed -i.bak 's/export //g' aws_creds_env_docker

AWS_IMAGE="${AWS_DOCKER_REPO}:latest"
docker pull ${AWS_IMAGE}
AWS="docker run --rm -u $(id -u) -v $PWD:/workspace -w /workspace -e AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION} --env-file ./aws_creds_env_docker ${AWS_IMAGE} aws"

# Vault auth
export VAULT_ADDR=https://vault-int.mckinsey-solutions.com
if [ "${BRANCH}" == "prod" ]; then
  export VAULT_BACKEND=mckube-prod
  vault auth -method=aws role=mckube-prod-rw-jenkins-mke
else
  export VAULT_BACKEND=mckube-npn
  vault auth -method=aws role=mckube-npn-rw-jenkins-mke
fi

# Assume role
source ./aws_creds_env.sh

# SSH setup
eval $(ssh-agent)
vault read -field=private ${VAULT_BACKEND}/${CLUSTER_NAME}/ssh | ssh-add -

export DIR_PREFIX="/workspace"

if [ -f snapshots.txt ]; then
  mv snapshots.txt "snapshots-$(date -u +%d%b%YZ%H%M).txt"
fi

function trigger {
    i=$1
    d=$2
  
    VOLUME_ID=$(${AWS} ec2 describe-instances --instance=${i} | jq -r '.Reservations[0].Instances[0].BlockDeviceMappings[] | select(.DeviceName == "'${d}'") | .Ebs.VolumeId')
    echo "Creating snapshot of '${VOLUME_ID}'"
    snapshot_id=$(${AWS} ec2 create-snapshot --volume-id ${VOLUME_ID} --description "Snapshot by $(whoami) at $(date)" | jq -r .SnapshotId)
    echo "Tagging snapshot '${snapshot_id}'"
    ${AWS} ec2 describe-tags --filters "Name=resource-id,Values=${VOLUME_ID}" --output json | jq '[.Tags[] | {"Key": .Key, "Value": .Value}] | {"DryRun": false, "Resources": ["'${snapshot_id}'"], "Tags": .}' > $PWD/${VOLUME_ID}.json
    ${AWS} ec2 create-tags --cli-input-json file://${DIR_PREFIX}/${VOLUME_ID}.json

    echo $snapshot_id >> $PWD/snapshots.txt

    rm -f $PWD/${VOLUME_ID}.json
}

EC2_IDS=$(${AWS} autoscaling describe-auto-scaling-groups --auto-scaling-group-names master-${AWS_DEFAULT_REGION}a.masters.${CLUSTER_NAME} master-${AWS_DEFAULT_REGION}b.masters.${CLUSTER_NAME} master-${AWS_DEFAULT_REGION}c.masters.${CLUSTER_NAME} --query "AutoScalingGroups[].Instances[].InstanceId" --output text | tr '\t' ' ')
EC2_HOSTS=$(${AWS} ec2 describe-instances --instance-ids ${EC2_IDS} --query Reservations[].Instances[].PrivateDnsName --output text)
DEVICES=("/dev/xvdu" "/dev/xvdv")

echo "Freezing filesystems..."
for h in $EC2_HOSTS; do
  MOUNTS=$(ssh -o StrictHostKeyChecking=no -A core@bastion.${CLUSTER_NAME} 'ssh -o StrictHostKeyChecking=no core@'$h' ls /mnt/')
  ssh -o StrictHostKeyChecking=no -A core@bastion.${CLUSTER_NAME} 'ssh -o StrictHostKeyChecking=no core@'$h' sync'
  for m in $MOUNTS; do
    ssh -o StrictHostKeyChecking=no -A core@bastion.${CLUSTER_NAME} 'ssh -o StrictHostKeyChecking=no core@'$h' sudo "fsfreeze -f /mnt/'$m'"'
  done
done

echo "Triggering snapshots..."
for i in $EC2_IDS; do
  for d in ${DEVICES[@]}; do
    trigger "$i" "$d" &
  done
done

wait
sleep 2

echo "Unfreezing filesystems..."
for h in $EC2_HOSTS; do
  MOUNTS=$(ssh -o StrictHostKeyChecking=no -A core@bastion.${CLUSTER_NAME} 'ssh -o StrictHostKeyChecking=no core@'$h' ls /mnt/')
  for m in $MOUNTS; do
    ssh -o StrictHostKeyChecking=no -A core@bastion.${CLUSTER_NAME} 'ssh -o StrictHostKeyChecking=no core@'$h' sudo "fsfreeze -u /mnt/'$m'"'
  done
done

echo "Snapshots successfully triggered!"
echo "Waiting for snapshots to complete..."
${AWS} ec2 wait snapshot-completed --snapshot-ids $(cat snapshots.txt |  tr '\n' ' ')

echo "Snapshots generated are:"
cat snapshots.txt