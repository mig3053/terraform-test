#!/bin/bash

# Vault auth
export VAULT_ADDR=https://vault-int.mckinsey-solutions.com
if [ "${BRANCH}" == "prod" ]; then
  export VAULT_BACKEND=mckube-prod
  vault auth -method=aws role=mckube-prod-rw-jenkins-mke
else
  export VAULT_BACKEND=mckube-npn
  vault auth -method=aws role=mckube-npn-rw-jenkins-mke
fi

# Assume role
source ./aws_creds_env.sh

# SSL Certificate for Internal LoadBalancer
internal_elb() {
  export AWS_DEFAULT_REGION=$REGION
  echo "Default AWS region is $AWS_DEFAULT_REGION"

  #Download CA key and crt from s3
  ${AWS} s3 cp --recursive s3://${CLUSTER_NAME}-kops/${CLUSTER_NAME}/pki/private/ca/ . && mv *.key ca.key
  ${AWS} s3 cp --recursive s3://${CLUSTER_NAME}-kops/${CLUSTER_NAME}/pki/issued/ca/ . && mv *.crt ca.crt

  if ${AWS} iam get-server-certificate --server-certificate-name=int-api-elb.${CLUSTER_NAME}
  then
        echo "There are already ssl certificates..."
        TF_VAR_SSLARN=$(${AWS} iam get-server-certificate --server-certificate-name=int-api-elb.${CLUSTER_NAME} | awk '/arn:/{print $2; exit}' | cut -d'"' -f2 )
        echo $TF_VAR_SSLARN
        export TF_VAR_SSLARN
  else
        #Here we create the SSL certificate and write it to Vault
        openssl genrsa -out int-api-elb.${CLUSTER_NAME}.key 2048
        openssl req -subj "/C=US/ST=New York/O=McKinsey&Company/CN=int-api-elb.${CLUSTER_NAME}" -new -key int-api-elb.${CLUSTER_NAME}.key -out int-api-elb.${CLUSTER_NAME}.csr
        openssl x509 -req -in int-api-elb.${CLUSTER_NAME}.csr -CA ca.crt -CAkey ca.key -set_serial 01 -out int-api-elb.${CLUSTER_NAME}.crt -days 3650 -sha256
        vault write ${VAULT_BACKEND}/${CLUSTER_NAME}/int-elb-ssl key=@int-api-elb.${CLUSTER_NAME}.key crt=@int-api-elb.${CLUSTER_NAME}.crt csr=@int-api-elb.${CLUSTER_NAME}.csr
        TF_VAR_SSLARN=$(${AWS} iam upload-server-certificate --server-certificate-name int-api-elb.${CLUSTER_NAME} --certificate-body file://int-api-elb.${CLUSTER_NAME}.crt  --private-key file://int-api-elb.${CLUSTER_NAME}.key | awk '/arn:/{print $2; exit}' | cut -d "," -f1 )
        echo $TF_VAR_SSLARN
        export TF_VAR_SSLARN
  fi

  # Get current AWS account alias(es)
  export AWS_ACCOUNT_ALIAS=$(${AWS} iam list-account-aliases | jq -r '.AccountAliases[0]')
  echo "AWS account alias is $AWS_ACCOUNT_ALIAS"

  # Set S3 bucket name and prefix variables for ELB logs to using them in Terraform script
  echo "Based on the current AWS account alias, we set the following values:"
  if [[ $(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .Environment }}") == "test" ]]; then
    export TF_VAR_ELB_S3_BUCKET_NAME="aus1c-ndm-ss01"
  else
    export TF_VAR_ELB_S3_BUCKET_NAME="aus1p-ndm-ss01"
  fi
  echo "S3 bucket name: $TF_VAR_ELB_S3_BUCKET_NAME"
  export TF_VAR_ELB_S3_BUCKET_PREFIX="${AWS_ACCOUNT_ALIAS}"
  echo "S3 bucket prefix: $TF_VAR_ELB_S3_BUCKET_PREFIX"

  export TF_RUN="docker run --rm \
                  -e AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID} \
                  -e AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY} \
                  -e AWS_SESSION_TOKEN=${AWS_SESSION_TOKEN} \
                  -e TF_VAR_SSLARN=${TF_VAR_SSLARN} \
                  -e TF_VAR_ELB_S3_BUCKET_NAME=${TF_VAR_ELB_S3_BUCKET_NAME} \
                  -e TF_VAR_ELB_S3_BUCKET_PREFIX=${TF_VAR_ELB_S3_BUCKET_PREFIX} \
                  -v $(pwd):/workdir \
                  -v $HOME/.ssh:/root/.ssh:ro \
                  ${TERRAFORM_IMAGE}"

  vault write ${VAULT_BACKEND}/${CLUSTER_NAME}/ca crt=@ca.crt key=@ca.key
}

# Kops repo
export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
export KOPS_DOCKER_REPO="quay-int.mckinsey-solutions.com/nvt-platform/kops"
export BUCKET_NAME="$CLUSTER_NAME-kops"
export KOPS_VERSION=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .KopsVersion }}")
export BUCKET=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .LibsS3Bucket }}")
export KOPS_IMAGE="${KOPS_DOCKER_REPO}:${KOPS_VERSION}"
export KUBECTL="docker run --entrypoint /usr/local/bin/kubectl -v ${PWD}:/mnt --rm ${KOPS_IMAGE} --kubeconfig=/mnt/kubeconfig"
export KOPS_BASE_URL=https://s3${KOPS_S3_CONTEXT}.amazonaws.com/${BUCKET}/kops/${KOPS_VERSION}

# AWS CLI repo
export AWS_DOCKER_REPO="quay-int.mckinsey-solutions.com/nvt-platform/aws"

# Export the variables from the golang template
export KOPS_STATE_STORE="s3://${BUCKET_NAME}"
export NAME="${CLUSTER_NAME}"
export KOPS="docker run --rm -u $(id -u) -v $PWD:/workspace -w /workspace -e KOPS_FEATURE_FLAGS=+DrainAndValidateRollingUpdate -e HOME=/workspace -e KOPS_BASE_URL=${KOPS_BASE_URL} -e KOPS_STATE_STORE=${KOPS_STATE_STORE} --env-file ./aws_creds_env_docker ${KOPS_IMAGE}"

# Setting up the AWS CLI
REGION=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .Region }}")
AWS_DEFAULT_REGION=$REGION
export AWS_DEFAULT_REGION

# Terraform image setup
export TERRAFORM_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/terraform-provider-newrelicinfra:v0.1.1"
docker pull ${TERRAFORM_IMAGE}
#TF_RUN is set as part of internal_elb

#Merging the VPC configuration with main configuration
cat vpc.yaml >> mckube-configuration.yaml

#McKube Config Applier part
docker pull ${DOCKER_IMAGE}
docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/cluster.yaml.tmpl > cluster.yaml
docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/kops-state.tf.tmpl > kops-state.tf
docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/override.tf.tmpl > override.tf
docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/internal-elb.tf.tmpl > internal-elb.tf

echo "mckube-config:"
cat mckube-configuration.yaml

echo "------------"
echo "cluster yaml:"
cat cluster.yaml

if [[ "$(docker run --rm -v $(pwd):/workdir/config "${DOCKER_IMAGE}" -config-path ./config -template "{{.BGPRR}}")" == "true" ]]; then
  if [ ! -d "bgp_data" ]; then
    mkdir bgp_data
  fi

  docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/bgp/bgp.tf.tmpl > bgp.tf
  docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/bgp/bgp_data/aws_iam_role_bgp_policy > bgp_data/aws_iam_role_bgp_policy
  docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/bgp/bgp_data/aws_iam_role_policy_bgp_policy > bgp_data/aws_iam_role_policy_bgp_policy
  docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/bgp/bgp_data/aws_launch_configuration_bgp_user_data.tmpl > bgp_data/aws_launch_configuration_bgp_user_data

  # Add New Relic API key to S3
  SECRETS_BUCKET=$(docker run --rm -v $(pwd):/workdir/config "${DOCKER_IMAGE}" -config-path ./config -template "{{.SecretsS3Bucket}}")
  NR_API_KEY="NRIA_LICENSE_KEY=$(vault read -field=license_key ${VAULT_BACKEND}/${BRANCH}/new-relic)"
  echo $NR_API_KEY | aws s3 cp - s3://${SECRETS_BUCKET}/newrelic/${CLUSTER_NAME}/apikey
  unset SECRETS_BUCKET NR_API_KEY

fi

if [ "${REGION}" != "us-east-1" ]
then
    KOPS_S3_CONTEXT="-${REGION}"
fi

docker run --rm -v $(pwd):/workdir/config -v $(pwd)/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/kube2iam-create-roles.sh.tmpl > kube2iam-create-roles.sh
chmod +x ./kube2iam-create-roles.sh
sh -x ./kube2iam-create-roles.sh

#KOPS ssh key
if vault list ${VAULT_BACKEND}/${CLUSTER_NAME}
then
       echo "There are already keys..."
else
       ssh-keygen -N "" -t rsa -b 4096 -f ${CLUSTER_NAME}
       vault write ${VAULT_BACKEND}/${CLUSTER_NAME}/ssh public=@${CLUSTER_NAME}.pub private=@${CLUSTER_NAME}
fi


if [ ! -f "${CLUSTER_NAME}.pub" ]; then
	vault read -field=public ${VAULT_BACKEND}/${CLUSTER_NAME}/ssh > ${CLUSTER_NAME}.pub
fi

# Prep AWS creds for use with docker run
cp aws_creds_env.sh aws_creds_env_docker
sed -i.bak 's/export //g' aws_creds_env_docker

docker pull ${KOPS_IMAGE}

AWS_IMAGE="${AWS_DOCKER_REPO}:latest"
docker pull ${AWS_IMAGE}
AWS="docker run --rm -u $(id -u) -v $PWD:/workspace -w /workspace -e AWS_DEFAULT_REGION=${REGION} --env-file ./aws_creds_env_docker ${AWS_IMAGE} aws"

#check if there are already clusters deployed
if ${KOPS} get clusters ${CLUSTER_NAME}; then
  echo "Cluster Already Created...Updating configuration if needed!"
  ${KOPS} replace -f cluster.yaml --force
  ${KOPS} update cluster ${CLUSTER_NAME} --target terraform --out .
  internal_elb
  #TF_RUN is set as part of internal_elb
  ${TF_RUN} init
  if ! ${TF_RUN} plan -out=/workdir/nrplanfile -detailed-exitcode; then
    echo "-- $(date) -  Applying changes..."
    ${TF_RUN} apply -auto-approve /workdir/nrplanfile
  else
    echo "-- No changes to apply"
  fi
  if ${KOPS} rolling-update cluster ${CLUSTER_NAME} --instance-group=master-${REGION}a,master-${REGION}b,master-${REGION}c | grep -i NeedsUpdate; then
    RR_ENABLED=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .BGPRR }}")
    if [ "${RR_ENABLED}" == "true" ]; then
      echo "-- $(date) - Scaling up Route Reflectors..."
      GROUP_NAME="bgp.${CLUSTER_NAME}"
      GROUP=$(${AWS} autoscaling describe-auto-scaling-groups --auto-scaling-group-names ${GROUP_NAME} --query 'AutoScalingGroups[0]')
      OLD_NODES=$(echo $GROUP | jq -r '.Instances[].InstanceId')
      OLD_CAPACITY=$(echo ${GROUP} | jq -r '.DesiredCapacity')
      OLD_MIN_SIZE=$(echo ${GROUP} | jq -r '.MinSize')
      OLD_MAX_SIZE=$(echo ${GROUP} | jq -r '.MaxSize')
      NEW_CAPACITY=$(echo ${GROUP} | jq -r '.DesiredCapacity * 2')
      ${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name ${GROUP_NAME} --min-size ${OLD_CAPACITY} --max-size ${NEW_CAPACITY} --desired-capacity ${NEW_CAPACITY}

      #Deploy calicoctl
      CALICOCTL_YAML="https://docs.projectcalico.org/v3.3/getting-started/kubernetes/installation/hosted/calicoctl.yaml"
      ${KUBECTL} apply -f ${CALICOCTL_YAML}

      while [ "$(${KUBECTL} exec -n kube-system calicoctl -- /calicoctl get bgppeer --output=json | jq -r '.items | length')" != "${NEW_CAPACITY}" ]
      do
        echo "$(date) - Waiting for new Route Reflectors..."
        sleep 5
      done
      ${KUBECTL} delete -f ${CALICOCTL_YAML}

      echo "-- $(date) - Terminating old Route Reflectors..."
      for N in $OLD_NODES
      do
        ${AWS} autoscaling terminate-instance-in-auto-scaling-group --instance-id ${N} --should-decrement-desired-capacity
      done

      echo "-- $(date) - Cleaning up Route Reflector ASG..."
      ${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name ${GROUP_NAME} --min-size ${OLD_MIN_SIZE} --max-size ${OLD_MAX_SIZE} --desired-capacity ${OLD_CAPACITY}

      echo "-- $(date) - Route Reflectors updated!"
    fi
    echo "-- $(date) -  Rolling update masters..."
    ${KOPS} rolling-update cluster ${CLUSTER_NAME} --force --yes --instance-group=master-${REGION}a,master-${REGION}b,master-${REGION}c --master-interval=8m0s
  fi

  INSTANCE_GROUPS=$(${KOPS} get instancegroups --name ${CLUSTER_NAME} -ojson | jq -r '.[] | select(.spec.role == "Node") | .metadata.name')

  for g in $INSTANCE_GROUPS; do
    echo "g is $g"
    if ${KOPS} rolling-update cluster ${CLUSTER_NAME} --instance-group=${g} | grep -i NeedsUpdate; then
      echo "-- $(date) -  Disable auto-scaling..."
      if ${KUBECTL} -n kube-system get deployment aws-cluster-autoscaler-aws-cluster-autoscaler
      then
        ${KUBECTL} -n kube-system scale deployment aws-cluster-autoscaler-aws-cluster-autoscaler --replicas=0
      else
        echo "-- $(date) - Autoscaler not found, won't disable"
      fi
      echo "-- $(date) - Scaling up instances in group ${g}..."
      GROUP_NAME="${g}.${CLUSTER_NAME}"
      GROUP=$(${AWS} autoscaling describe-auto-scaling-groups --auto-scaling-group-names ${GROUP_NAME} --query 'AutoScalingGroups[0]')
      OLD_NODES=$(${KUBECTL} get no -ojson | jq -r '.items[] | select(.metadata.labels."kops.mckinsey.cloud/instance-group" == "'${g}'") | .metadata.name')
      OLD_CAPACITY=$(echo ${GROUP} | jq -r '.DesiredCapacity')
      OLD_MIN_SIZE=$(echo ${GROUP} | jq -r '.MinSize')
      OLD_MAX_SIZE=$(echo ${GROUP} | jq -r '.MaxSize')
      NEW_CAPACITY=$(echo ${GROUP} | jq -r '.DesiredCapacity * 2.2 | floor')
      TARGET_CAPACITY=$(echo ${GROUP} | jq -r '.DesiredCapacity * 2.2 - .DesiredCapacity | floor')
      ${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name ${GROUP_NAME} --min-size ${OLD_CAPACITY} --max-size ${NEW_CAPACITY} --desired-capacity ${NEW_CAPACITY}

      while [ "$(${AWS} autoscaling describe-auto-scaling-groups --auto-scaling-group-names ${GROUP_NAME} --query 'length(AutoScalingGroups[0].Instances)')" != "${NEW_CAPACITY}" ]
      do
        echo "$(date) - Waiting for new instances in group ${g}..."
        sleep 5
      done

      while [ "$(${KUBECTL} get no -ojson | jq -r '.items[] | select(.metadata.labels."kops.mckinsey.cloud/instance-group" == "'${g}'") | .metadata.name' | wc -l)" != "${NEW_CAPACITY}" ]
      do
        echo "$(date) - Waiting for new instances from group ${g} to register with Kubernetes..."
        sleep 5
      done

      echo "-- $(date) - Suspending EC2 auto-scaling processes for group ${g}..."
      ${AWS} autoscaling suspend-processes --auto-scaling-group-name ${GROUP_NAME} --scaling-processes Launch AZRebalance

      echo "-- $(date) -  Cordon old nodes"
      for N in $OLD_NODES; do
        ${KUBECTL} cordon $N
      done
      echo "-- $(date) -  Starting to terminate old nodes from group ${g}..."
      for N in $OLD_NODES; do
        PROVIDER_ID=$(${KUBECTL} get no $N -ojson | jq -r '.spec.providerID')
        if [ "$(echo $PROVIDER_ID | cut -c1-6)" != "aws://" ]; then
          echo "---! Provider ID for Node $N is not in AWS format, Provider ID is \'$PROVIDER_ID\', this node will be skipped"
          continue
        fi
        EC2_ID="${PROVIDER_ID##*\/}"
        echo "---- $(date) - Draining Node ${N}::${EC2_ID} with 15 minute timeout"
        ! timeout --foreground 15m ${KUBECTL} drain $N --delete-local-data=true --force=true --ignore-daemonsets=true
        echo "---- $(date) - Terminating Node ${N}::${EC2_ID}"
        ${AWS} autoscaling terminate-instance-in-auto-scaling-group --instance-id ${EC2_ID} --should-decrement-desired-capacity
      done

      echo "-- $(date) -  Done terminating old nodes in group ${g}!"

      echo "-- $(date) -  Cleaning up ASG for group ${g}..."
      ${AWS} autoscaling resume-processes --auto-scaling-group-name ${GROUP_NAME}
      ${AWS} autoscaling update-auto-scaling-group --auto-scaling-group-name ${GROUP_NAME} --min-size ${OLD_MIN_SIZE} --max-size ${OLD_MAX_SIZE} --desired-capacity ${TARGET_CAPACITY}
      echo "-- $(date) -  Cleanup complete!"
    fi
  done

  echo "-- $(date) -  Re-enable auto-scaling..."
  if ${KUBECTL} -n kube-system get deployment aws-cluster-autoscaler-aws-cluster-autoscaler
  then
    ${KUBECTL} -n kube-system scale deployment aws-cluster-autoscaler-aws-cluster-autoscaler --replicas=1
  else
    echo "-- $(date) -  Autoscaler not found, won't enable"
  fi
  echo "-- $(date) -  Rollout complete!"

  if ${KOPS} rolling-update cluster ${CLUSTER_NAME} --instance-group=bastions | grep -i NeedsUpdate; then
    echo "-- $(date) -  Updating bastion..."
    ${KOPS} rolling-update cluster ${CLUSTER_NAME} --force --yes --instance-group=bastions
  fi
else
  echo "Creating New Cluster Configuration Files"
  ${KOPS} create -f cluster.yaml
  ${KOPS} create secret --name ${CLUSTER_NAME} sshpublickey admin -i ./${CLUSTER_NAME}.pub
  ${KOPS} update cluster ${CLUSTER_NAME} --target terraform --out .
  internal_elb
  #TF_RUN is set as part of internal_elb
  ${TF_RUN} init
  ${TF_RUN} plan -out=/workdir/nrplanfile
  ${TF_RUN} apply -auto-approve /workdir/nrplanfile
fi

# Re-auth with Vault in case our credentials have expired since the beginning of the job

#Abandon our assumed role so we can auth with Vault correctly
unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN

if [ "${BRANCH}" == "prod" ]; then
  export VAULT_BACKEND=mckube-prod
  vault auth -method=aws role=mckube-prod-rw-jenkins-mke
else
  export VAULT_BACKEND=mckube-npn
  vault auth -method=aws role=mckube-npn-rw-jenkins-mke
fi

# Push the mckube-configuration.yaml into Vault to be used by addons pipeline (nvt-helm-releases)
vault write ${VAULT_BACKEND}/${CLUSTER_NAME}/mckube-configuration file=@mckube-configuration.yaml


#END
