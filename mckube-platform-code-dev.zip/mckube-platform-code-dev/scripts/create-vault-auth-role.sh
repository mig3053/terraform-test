#!/bin/bash

# Assume role
source ./aws_creds_env.sh

# Config Applier
export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
docker pull ${DOCKER_IMAGE}
ROLE_NAME=$(docker run --rm -v ${PWD}:/workdir/config -v ${PWD}/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template "{{ .ClusterName }}-{{ .Stage }}-${NAMESPACE}-vault-auth")
docker run --rm -v ${PWD}:/workdir/config -v ${PWD}/templates:/workdir/templates ${DOCKER_IMAGE} -config-path ./config -template-file ./templates/vault-auth-role-assume-policy.json.tmpl > vault-auth-role-assume-policy.json

# Role name
aws iam create-role --role-name ${ROLE_NAME} --description "Role to assume to access Vault for use by the ${NAMEPSACE} Namespace" --assume-role-policy-document file://vault-auth-role-assume-policy.json

# No policies to attach to the role required
