export DOCKER_IMAGE="quay-int.mckinsey-solutions.com/nvt-platform/mckube-config-applier:${BRANCH}"
docker pull ${DOCKER_IMAGE}

BUCKET=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .LibsS3Bucket }}")
if [ "${BUCKET}" == "kubeupv2" ]; then
  echo "Using upstream Kops, nothing to do!"
  exit 0
fi

VPC_ID=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .KOPSVPC.Vpcid }}")
REGION=$(docker run --rm -v "$(pwd)":/workdir/config ${DOCKER_IMAGE} -config-path config/ -template "{{ .Region }}")
export AWS_DEFAULT_REGION=$REGION

python - $VPC_ID $BUCKET <<EOF
import botocore.session
import json
import sys
vpc = sys.argv[1]
bucket = sys.argv[2]
session = botocore.session.get_session()
client = session.create_client('s3')
response = client.get_bucket_policy(
  Bucket=bucket
)
print "Current policy:"
print json.dumps(response['Policy'])
policy = json.loads(response['Policy'])
statementExists=False
changed = False
for s in policy['Statement']:
  if s['Sid'] == 'AllowPublicReadFromVPC1':
    statementExists = True
    try:
      s['Condition']['StringEquals']['aws:sourceVpc']
    except KeyError:
      s['Condition'] = {'StringEquals': {'aws:sourceVpc': []}}
    if type(s['Condition']['StringEquals']['aws:sourceVpc']) is list and vpc not in s['Condition']['StringEquals']['aws:sourceVpc']:
      s['Condition']['StringEquals']['aws:sourceVpc'].append(vpc)
      print "Adding vpc "+vpc+" to bucket policy of "+bucket
      changed = True
    elif type(s['Condition']['StringEquals']['aws:sourceVpc']) in (str, unicode) and vpc != s['Condition']['StringEquals']['aws:sourceVpc']:
      s['Condition']['StringEquals']['aws:sourceVpc'] = [ s['Condition']['StringEquals']['aws:sourceVpc'], vpc ]
      print "Adding vpc "+vpc+" to bucket policy of "+bucket
      changed = True
    break
if changed:
  print "Updating policy"
  response = client.put_bucket_policy(
  Bucket=bucket,
  Policy=json.dumps(policy)
)
print "Current policy:"
print json.dumps(policy)
EOF